/**
* DoublyLinked.hpp
* Bu dosya DoublyLinked.cpp dosyasının başlık dosyasıdır.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 11.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef DOUBLYLINKED_HPP
#define DOUBLYLINKED_HPP
#include "Iterator.hpp"
#include "Node.hpp"

 class DoublyLinked{
 private:
    Node *head;
    int size;
    int index;
    Iterator IterateFromPrevIndex(int index);
    Iterator IterateFromFirstNode();
 public:
     DoublyLinked();
     bool IsEmpty();
     void Screen();//ekrana yazdırma
     int Count();
     void Add(const int& obj);//liste sonuna ekleme
     void Insert(int index,const int& obj);
     int IndexOf(const int& obj);
     void Reversed(int index);
     void Remove(const int& obj);
     void RemoveAt(int index);
     void Clear();
     ~DoublyLinked();
 };
 
 
 

#endif // DOUBLYLINKED_HPP