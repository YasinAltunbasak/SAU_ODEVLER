/**
* Node.hpp
* Bu dosya Node.cpp dosyasının başlık dosyasıdır.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 08.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef NODE_HPP
#define NODE_HPP
#include <iostream>
using namespace std;
class Node{
	public:
        int data;
		Node *head;
		Node *next;
		Node *prev;
		
		Node(const int& data, Node *next, Node *prev);

			
    

};
#endif 