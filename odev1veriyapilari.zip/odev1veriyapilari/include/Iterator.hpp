/**
* Iterator.hpp
* Bu dosya Iterator.cpp dosyasının başlık dosyasıdır.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 09.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef ITERATOR_HPP
#define ITERATOR_HPP
#include "Node.hpp"


class Iterator{
	public:
		Node *current;
		Iterator();
		Iterator(Node *node);
		bool IsEndNode();
		void StepNext();
		void StepBack();
		const int& GetCurrentData();
};

#endif