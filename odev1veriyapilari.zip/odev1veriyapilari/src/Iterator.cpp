/**
* Iterator.cpp
* Bu dosya liste üzerinde dolaşmamızı sağlamaktadır.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 09.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "Node.hpp"
#include "Iterator.hpp"
#include <iostream>

		
		Iterator::Iterator(){
			current=NULL; //currentı varsayılan olarak NULL aldık.
		}
		Iterator::Iterator(Node *node){
			current=node; 
		}
		bool Iterator::IsEndNode(){
			return current == NULL;//son ddüğümün gösterdiği adres NULL
		}
		void Iterator::StepNext(){
			if(!IsEndNode())
				current=current->next;//bulunan düğümden sonraki düğüme geçirten kod bloğu
		}
		void Iterator::StepBack(){
			if(!IsEndNode())
				current=current->prev;//bulunan düğümden önceki düğüme geçiren kod bloğu
		}
		const int& Iterator::GetCurrentData(){
			return current->data;// üzerinde durulan düğümün değerini gösterir.
		}
