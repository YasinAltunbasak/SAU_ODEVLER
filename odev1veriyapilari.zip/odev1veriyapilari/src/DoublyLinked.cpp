/**
* DoublyLinked.cpp
* Bu dosya liste üzerinde değiştirme yazma ve döndürme gibi özellikleri çalıştırmaktadır.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 10.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "Iterator.hpp"
#include "Node.hpp"
#include "DoublyLinked.hpp"
#include <iostream>
#include <sstream>
using namespace std;



Iterator DoublyLinked::IterateFromPrevIndex(int index){
	if(!(index < 0 || index > Count())){
				int i=0;
				Iterator  itr(head);
				while(!itr.IsEndNode() && index != i++)
					itr.StepNext();
				return itr;
			}
			return NULL;
}

Iterator DoublyLinked::IterateFromFirstNode(){
if(!IsEmpty())
			 return Iterator (head->next);
			return NULL;
}

DoublyLinked::DoublyLinked(){
	head= NULL;
	size = 0;
	index = 0;
}




void DoublyLinked::Add(const int& obj){
    Insert(Count(), obj);
}

void DoublyLinked::Insert(int index,const int& obj){
            Iterator itr;
			itr = IterateFromPrevIndex(index);
			Node *newNext = itr.current->next;
			itr.current->next = new Node(obj, newNext, itr.current);
			if(newNext != NULL) 
				newNext->prev = itr.current->next;
			size++;
}

bool DoublyLinked::IsEmpty(){
    return head->next == NULL;
}

int DoublyLinked::Count(){
    return size;
}

void DoublyLinked::Reversed(int index){
	for(Iterator itr = IterateFromPrevIndex(index+1);itr.current != head;itr.StepBack())
		cout<<itr.GetCurrentData()<<endl;
}
void DoublyLinked::Remove(const int& obj){
		int index=IndexOf(obj);
		RemoveAt(index);
}
void DoublyLinked::RemoveAt(int index){
		Iterator itr;
		itr = IterateFromPrevIndex(index);
		if(itr.current->next != NULL){
		Node *oldNode = itr.current->next;
			itr.current->next=itr.current->next->next;
				if(oldNode->next != NULL) 
				oldNode->next->prev = oldNode->prev;
				delete oldNode;
				size--;
			}
}

int DoublyLinked::IndexOf(const int& obj){
			int index=0;
			for(Iterator itr(head->next);!itr.IsEndNode();itr.StepNext()){
				if(itr.GetCurrentData() == obj)
					return index;
				index++;
			}
			return -1;
		}

void DoublyLinked::Clear(){
while(!IsEmpty()){
     	RemoveAt(0);
			}
}

DoublyLinked::~DoublyLinked(){
	Clear();
	delete head;
} 