/**
* Node.cpp
* Bu dosya ana düğüm yapısını oluşturmaktadır.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 08.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "../include/node.hpp"
#include <iostream>
#include <string>
using namespace std;

Node::Node(const int& data, Node *next=NULL, Node *prev=NULL){
	
	this->data = data;
	this->next = next;
	this->prev = prev;
	
}