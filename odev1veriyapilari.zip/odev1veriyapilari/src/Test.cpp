/**
* Test.cpp
* Bu dosya ana dosya olup Sayilar.txt dosyasını okuyup ekrana yazdırmakta ve düğüme işlemektedir.
* Yaz okulu 1. öğretim B grubu
* 1. ödev
* 11.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "../include/Node.hpp"
#include "../include/Iterator.hpp"
#include "../include/DoublyLinked.hpp"
using namespace std;

int main(){
    DoublyLinked *sayilar = new  DoublyLinked();
    
    int sayac1 = 1;
    int n;
  
    char rakam;
    ifstream dosyaOku("Sayilar.txt");

    if(dosyaOku.is_open()){
        while(dosyaOku.get(rakam)){
            if( rakam!= ' '){
            cout <<rakam;
             if(sayac1==3){
                cout<< "||";
                sayac1 = 0;
            }
             sayac1++;

            }
            else {
                cout<<" "<<n<<". liste"<<endl;
                n++;
            }
            
            
           
        }
    }
    return 0;
    delete sayilar;
   
}