/**
* Node.cpp
* Bu dosya düğüm bilgilerini tutmaktadır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 23.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "..\include\Node.hpp"
#include "..\include\People.hpp"
#include "..\include\Stack.hpp"
#include <iostream>
#include <string>

using namespace std;

Node::Node(string bilgi[], int yas, Node *sol, Node *sag){
    this->kisi = new People(bilgi[0], bilgi[1], bilgi[2]);
    this->stack1 = new Stack1();
     this->stack2 = new Stack2();
    this->sag = sag;
    this->sol = sol;
    this->yas = yas;
    this->yukseklik = 0;
    this->derinlik = -1;
}