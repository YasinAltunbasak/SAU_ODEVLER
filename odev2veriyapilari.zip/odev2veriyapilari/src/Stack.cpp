/**
* Stack.cpp
* Bu dosya yıgıt bilgilerini tutmaktadır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 25.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "..\include\Stack.hpp"
#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;


Stack1::Stack1(){
        this->sayilar1 = NULL;
        this->stackBasi1 = -1;
        this->elemanSayisi1 = 0;
        this->kapasite1 = 0;
    }

    bool Stack1::isEmpty(){
        return stackBasi1 == -1;
    }

    bool Stack1::doluMu(){
        return elemanSayisi1 == kapasite1;
    }

    void Stack1::yerAc(int boyut){
        char *tmp =new char[boyut];
        for (int i=0; i<elemanSayisi1;i++)
            tmp[i] = sayilar1[i];
        if(sayilar1 !=NULL)
            delete[] sayilar1;
            sayilar1 =tmp;
            kapasite1=boyut;
    }

   void Stack1::push(int eleman)
{
    if (doluMu()){
        yerAc(max(1, 2 * kapasite1));
    }
    stackBasi1++;
    sayilar1[stackBasi1] = eleman;
    elemanSayisi1++;
}

char Stack1::pop(){
    if(!isEmpty()){
    char sayi = sayilar1[stackBasi1];
    stackBasi1--;
    return sayi;
    }
    else{
        return 0;
    }
}

char Stack1::top()
{
    if (!isEmpty())
        return sayilar1[stackBasi1];
	else
	{
		return 0;
	}
}
//Stack1 yükseklik, Stack 2 derinlik için.
Stack2::Stack2(){
        this->sayilar2 = NULL;
        this->stackBasi2 = -1;
        this->elemanSayisi2 = 0;
        this->kapasite2 = 0;
    }

    bool Stack2::isEmpty(){
        return stackBasi2 == -1;
    }

    bool Stack2::doluMu(){
        return elemanSayisi2 == kapasite2;
    }

    void Stack2::yerAc(int boyut){
        char *tmp =new char[boyut];
        for (int i=0; i<elemanSayisi2;i++)
            tmp[i] = sayilar2[i];
        if(sayilar2 !=NULL)
            delete[] sayilar2;
            sayilar2 =tmp;
            kapasite2=boyut;
    }

   void Stack2::push(int eleman)
{
    if (doluMu()){
        yerAc(max(1, 2 * kapasite2));
    }
    stackBasi2++;
    sayilar2[stackBasi2] = eleman;
    elemanSayisi2++;
}

char Stack2::pop(){
    if(!isEmpty()){
    char sayi = sayilar2[stackBasi2];
    stackBasi2--;
    return sayi;
    }
    else{
        return 0;
    }
}

char Stack2::top()
{
    if (!isEmpty())
        return sayilar2[stackBasi2];
	else
	{
		return 0;
	}
}