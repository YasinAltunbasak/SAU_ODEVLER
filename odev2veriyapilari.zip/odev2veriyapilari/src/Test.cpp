/**
* Test.cpp
* Bu dosya ana dosya olup kisiler.txt dosyasını okuyup Avl agacına eklemektedir.
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 26.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "..\include\Node.hpp"
#include "..\include\AvlTree.hpp"
#include "..\include\Stack.hpp"
#include "..\include\People.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

void Ekleme(string satir, AvlTree *agac){
    string dizi[3] = {"","",""};
    int sayac = 0;
    int yas;
    string word= "";
    for(auto letter : satir){
        if(letter == '#'){
            dizi[sayac]= word;
            word = "";
            sayac++;
        }
        else
        word =word + letter;
    }

    dizi[sayac] = word;
    agac->Ekle(dizi,yas);
    sayac = 0;

}
int main(){

    ifstream dosyaOku("kisiler.txt");
    char karakter;
    string s_number= "";

    if(dosyaOku.is_open())
    {
        AvlTree *agac = new AvlTree;
            while (dosyaOku.get(karakter))
            {
                if(karakter == '\n'){
                   Ekleme(s_number,agac);
                   s_number ="";

                }
                 s_number += karakter;
            }
            Ekleme(s_number,agac);

            agac->LevelOrder();
            agac->~AvlTree();
            delete agac;
            dosyaOku.close();
            
            
    }

    
}