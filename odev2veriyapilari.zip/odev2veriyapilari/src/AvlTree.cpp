/**
* AvlTree.cpp
* Bu dosya Avl agacının sistemini oluşturmaktadır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 22.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include <string>
#include <iostream>
#include <cmath>
#include "..\include\Node.hpp"
#include "..\include\AvlTree.hpp"
using namespace std;

AvlTree::AvlTree(){
    root =NULL;
}

 int AvlTree::Yukseklik(Node *child_Node) const{
	 if (child_Node == NULL)
        return -1;// Ortada düğüm yoksa yükseklik anlamsızdır. Kodun çalışması adına -1 verilmektedir.
	else{
	int n = 0;
	//yukseklik atama
	if (child_Node->yukseklik == child_Node->eskiyukseklik)
    {
        child_Node->stack1->push(n);
		n++;
    }
	else if(child_Node->yukseklik > child_Node->eskiyukseklik)
    {
        child_Node->stack1->push(n);
		n--;
    }
    else if(child_Node->yukseklik < child_Node->eskiyukseklik)
    {
        child_Node->stack1->push(n);
		n++;
    }
    return 1 + max(Yukseklik(child_Node->sol), Yukseklik(child_Node->sag));
  }
}

Node *AvlTree::AraveEkle(Node *child_Node,string dizi[], int yas){
	// child_Node = z, child_Node->sol = y, yas = x,w
		if (child_Node == NULL)
		{
			child_Node = new Node(dizi,yas,NULL,NULL);
			child_Node ->stack1->push('0');
			child_Node ->stack2->push('0');
		}
		else if (yas < child_Node->yas) // y, z'nin sol çocuğu ise
		{
			child_Node->sol = AraveEkle(child_Node->sol, dizi,yas);
			if (Yukseklik(child_Node->sol) - Yukseklik(child_Node->sag) == 2)
			{
				// Sol Sol Durumu
				if (yas < child_Node->sol->yas) // x, y'nin sol çocuğu ise
					child_Node = SolCocukIleDegistir(child_Node); //sağa dönüş z
				else // Sol Sağ Durumu
				{														  
					child_Node->sol = SagCocukIleDegistir(child_Node->sol); // sola dönüş y
					child_Node = SolCocukIleDegistir(child_Node); // sağa dönüş z
				}
			}
		}
		else if (yas > child_Node->yas)
		{
			child_Node->sag = AraveEkle(child_Node->sag,dizi, yas);

			if (Yukseklik(child_Node->sag) - Yukseklik(child_Node->sol) == 2)
			{
				// Sağ Sağ Durumu
				if (yas > child_Node->sag->yas)
					child_Node = SagCocukIleDegistir(child_Node);
				else
				{ // Sağ Sol Durumu
					child_Node->sag = SolCocukIleDegistir(child_Node->sag);
					child_Node = SagCocukIleDegistir(child_Node);
				}
			}
		}
		else
			; // Aynı eleman var.

		//Yüksekliği güncelle
		child_Node->yukseklik = Yukseklik(child_Node);
		return child_Node;	
}


Node *AvlTree::SolCocukIleDegistir(Node *child_Node){
   //swap
		Node *tmp = child_Node->sol;
		child_Node->sol = tmp->sag;
		tmp->sag = child_Node;

		// Yükseklikleri Güncelle
		child_Node->yukseklik = Yukseklik(child_Node);
		tmp->yukseklik = max(Yukseklik(tmp->sol), child_Node->yukseklik) + 1; // Bir düğümün yüksekliği en yüksek çocuğunun bir fazlasıdır

		return tmp;
}

Node *AvlTree::SagCocukIleDegistir(Node *child_Node){
    Node *tmp = child_Node->sag;
    child_Node->sag = tmp->sol;
    tmp->sol = child_Node;

    // Yükseklikleri Güncelle
    child_Node->yukseklik = child_Node->yukseklik;
    tmp->yukseklik = child_Node->yukseklik;

    child_Node->yukseklik = Yukseklik(child_Node);
    tmp->yukseklik = max(Yukseklik(tmp->sag), child_Node->yukseklik) + 1;
    
    return tmp;
}

void AvlTree::SeviyeyiYazdır(Node *child_Node,int seviye){
   if(child_Node ==NULL)
	return;
	if(seviye==0)
		cout<< child_Node->kisi->getIsim() <<" "<< child_Node->kisi->getYas()<<" "
			<< child_Node->kisi->getBoy() << " Yigitlar: Y(";
		while(!child_Node->stack1->isEmpty()){

		cout<< child_Node->stack1->pop()<<"," <<") , D(";
		cout<< child_Node->stack2->pop()<<"," <<") ";
			
		}
		cout<<endl;
}

void addDepth(Node *n, int currentDepth) {
    if (n == NULL) return; // check base condition

    int eskiDerinlik =  n->derinlik ;
    int d =0;
    if( n->derinlik!=-1){
    if( eskiDerinlik <  currentDepth){
        n->stack2->push(d);
		d--;
    }
    else if(eskiDerinlik ==  currentDepth){
        n->stack2->push(d);
		d++;
    }
    else{
        n->stack2->push(d);
		d++;
    }
    }
    n->derinlik = currentDepth;


}

void AvlTree::DugumKontrol(Node *child){
	DugumKontrol(child->sol);
	DugumKontrol(child->sag);
}

bool AvlTree::Bosmu(){
    return root == NULL;
}

void AvlTree::Ekle(string dizi[], int yeni){
	root =AraveEkle(root,dizi,yeni);
	addDepth(root,0);
}

void AvlTree::LevelOrder(){
	int h=Yukseklik();
	for (int level =0; level <=h;level++)
	SeviyeyiYazdır(root, level);
}

int AvlTree::Yukseklik(){
    return Yukseklik(root);
}

bool AvlTree::NodeSil(Node *&child_Node){
    Node *delete_Node = child_Node;
    if (child_Node->sag == NULL)
			child_Node = child_Node->sol;
		else if (child_Node->sol == NULL)
			child_Node = child_Node->sag;
		else
		{
			delete_Node = child_Node->sol;
			Node *mother_Node = child_Node;
			while (delete_Node->sag != NULL)
			{
				mother_Node = delete_Node;
				delete_Node = delete_Node->sag;
			}
			child_Node->yas = delete_Node->yas;
			if (mother_Node == child_Node)
				child_Node->sol = delete_Node->sol;
			else
				mother_Node->sag = delete_Node->sol;
		}
		delete delete_Node;
		return true;

    }

void AvlTree::Temizle(){
    while (!Bosmu())
			NodeSil(root);
}

AvlTree::~AvlTree(){
    Temizle();
}