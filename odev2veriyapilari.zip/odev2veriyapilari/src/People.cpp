/**
* People.cpp
* Bu dosya kişi bilgilerini tutmaktadır.
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 24.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#include "../include/People.hpp"
#include <string>
using namespace std;

People::People(string isim, string yas, string boy){
    this->isim = isim;
    this->yas = yas;
    this->boy = boy;
}

string People::getBoy(){
    return boy;
}

string People::getYas(){
    return yas;
}

string People::getIsim(){
    return isim;
}