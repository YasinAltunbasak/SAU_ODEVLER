/**
* Stack.hpp
* Bu dosya Stack.cpp dosyasının başlık dosyasıdır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 21.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef STACK_HPP
#define STACK_HPP

class Stack1{
    public:
    char *sayilar1;
    char stackBasi1;
    int elemanSayisi1;
    int kapasite1;
    char eleman1;
    bool doluMu();
    void yerAc(int boyut);
    Stack1();
    bool isEmpty();
    void push(int eleman1);
    char pop();
    void makeEmpty();
    char top();
};

class Stack2{
    public:
    char *sayilar2;
    char stackBasi2;
    int elemanSayisi2;
    int kapasite2;
    char eleman2;
    bool doluMu();
    void yerAc(int boyut);
    Stack2();
    bool isEmpty();
    void push(int eleman2);
    char pop();
    void makeEmpty();
    char top();
};

#endif //STACK_HPP