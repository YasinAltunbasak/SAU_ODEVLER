/**
* Node.hpp
* Bu dosya Node.cpp dosyasının başlık dosyasıdır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 21.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef NODE_HPP
#define NODE_HPP
#include "../include/people.hpp"
#include "../include/Stack.hpp"
#include <string>
#include <sstream>
using namespace std;

class Node {
    public:
    People *kisi;
    Stack1 *stack1;
    Stack2 *stack2;
    int yas;
    int derinlik;
    int eskiDerinlik;
    int eskiyukseklik;
    int yukseklik;
    Node *sol;
    Node *sag;
    Node(string bilgi[],int yas, Node *sol,Node *sag);
};
#endif //NODE_HPP