/**
* AvlTree.hpp
* Bu dosya AvlTree.cpp dosyasının başlık dosyasıdır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 21.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef AVLTREE_HPP
#define AVLTREE_HPP


#include <string>
#include <iostream>

#include "Node.hpp"

class AvlTree{
   private:
    Node *root;
    int Yukseklik(Node *child_Node)const;
    Node *AraveEkle(Node *child_Node,string dizi[], int data);
    void SeviyeyiYazdır(Node *child_Node,int seviye);
    Node *SolCocukIleDegistir(Node *child_Node);
    Node *SagCocukIleDegistir(Node *child_Node);
    public:
    int Yukseklik();
    AvlTree();
    void DugumKontrol(Node *child);
    bool Bosmu();
    void Ekle(string dizi[], int yeni);
    bool NodeSil(Node *&child_Node);
    void Temizle();
    void LevelOrder();
    ~AvlTree();
};

#endif //AVLTREE_HPP    