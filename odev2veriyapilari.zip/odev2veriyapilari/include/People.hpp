/**
* People.hpp
* Bu dosya People.cpp dosyasının başlık dosyasıdır
* Yaz okulu 1. öğretim B grubu
* 2. ödev
* 21.08.2021
* g191210386 Yasin Altunbaşak yasin.altunbasak@ogr.sakarya.edu.tr

*/
#ifndef PEOPLE_HPP
#define PEOPLE_HPP
#include <string>
using namespace std;

class People{
    private:
    string isim;
    string yas;
    string boy;
    public:
    People(string isim,string yas,string boy);
    string getIsim();
    string getYas();
    string getBoy();
};
#endif //PEOPLE_HPP